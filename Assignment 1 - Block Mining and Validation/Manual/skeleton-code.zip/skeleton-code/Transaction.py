# DO NOT EDIT #
class Transaction:
    def __init__(self, id, sender, receiver, value_receiver, value_sender , UTXO, signature, time_stamp):
        self.id = id
        self.sender = sender
        self.receiver = receiver
        self.value_receiver = value_receiver
        self.value_sender = value_sender
        self.UTXO_input = UTXO
        self.signature = signature
        self.time_stamp = time_stamp
        self.signature_token=self.id+self.time_stamp
